package com.fitforge.app.ui

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fitforge.app.ble.LinkState
import com.fitforge.app.protocol.Commands
import com.fitforge.app.protocol.Confidence
import com.fitforge.app.protocol.Frame
import com.fitforge.app.protocol.Hex

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Root(vm) }
            }
        }
    }
}

@Composable
private fun Root(vm: AppViewModel) {
    var tab by remember { mutableStateOf(0) }
    val titles = listOf("اتصال", "الساعة", "رفع", "المساحة", "المختبر", "السجل")
    Column(Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = tab) {
            titles.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            when (tab) {
                0 -> ConnectTab(vm)
                1 -> WatchTab(vm)
                2 -> UploadTab(vm)
                3 -> SpaceTab(vm)
                4 -> LabTab(vm)
                else -> LogTab(vm)
            }
        }
    }
}

@Composable
private fun ConnectTab(vm: AppViewModel) {
    val state by vm.link.state.collectAsState()
    val devices by vm.link.devices.collectAsState()
    val perms = if (Build.VERSION.SDK_INT >= 31)
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.all { it }) vm.link.startScan() else vm.log("الأذونات مرفوضة")
    }
    Text("الحالة: $state", fontSize = 16.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { launcher.launch(perms) }) { Text("بحث عن الساعة") }
        OutlinedButton(onClick = { vm.link.disconnect() }) { Text("قطع") }
        OutlinedButton(onClick = { vm.repairConnection() }) { Text("إصلاح الاتصال") }
    }
    devices.forEach { d ->
        Card(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(d.name.ifEmpty { "(بدون اسم)" })
                    Text("${d.address}  ${d.rssi}dBm", fontSize = 12.sp)
                }
                Button(onClick = { vm.link.connect(d.address) }) { Text("اتصال") }
            }
        }
    }
}

@Composable
private fun WatchTab(vm: AppViewModel) {
    var confirmReset by remember { mutableStateOf(false) }
    Text("معلومات الساعة", fontSize = 16.sp)
    Text(vm.dialInfo?.summary() ?: "لم تُقرأ بعد")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { vm.send(Commands.readDialInfo()) }) { Text("قراءة المعلومات") }
        Button(onClick = { vm.send(Commands.syncTime()) }) { Text("مزامنة الوقت") }
    }
    Text("إعادة ضبط الساعة تمسح بياناتها. اضغط مرتين للتأكيد.", fontSize = 12.sp)
    Button(onClick = { if (confirmReset) { vm.send(Commands.resetWatch); confirmReset = false } else confirmReset = true }) {
        Text(if (confirmReset) "تأكيد: إعادة الضبط الآن" else "إعادة ضبط الساعة")
    }
}

@Composable
private fun UploadTab(vm: AppViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.pick(u) }
    val data = vm.pickedBytes
    Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("اختيار ملف (.bin / .fpk)") }
    if (data != null) {
        val plan = vm.engine.plan(data, vm.cfg)
        Text("${vm.pickedName}  —  ${data.size} بايت  —  ${plan.packets} حزمة  —  ~${plan.estSeconds} ث")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("dial", "game", "file").forEach { k ->
                if (vm.pickedKind == k) Button(onClick = { vm.pickedKind = k }) { Text(k) }
                else OutlinedButton(onClick = { vm.pickedKind = k }) { Text(k) }
            }
        }
        if (vm.pickedKind == "dial") {
            OutlinedTextField(value = vm.dialStartHex, onValueChange = { vm.dialStartHex = it },
                label = { Text("حمولة أمر البدء (HEX)") }, modifier = Modifier.fillMaxWidth())
        }
        var chunk by remember { mutableStateOf(vm.cfg.chunk.toString()) }
        OutlinedTextField(value = chunk, onValueChange = { chunk = it; it.toIntOrNull()?.let { n -> vm.cfg.chunk = n } },
            label = { Text("حجم الحزمة (120 أو 200)") }, modifier = Modifier.fillMaxWidth())
        val free = vm.ledger.freeBytes()
        Text("المتاح الآمن: ${if (vm.ledger.budgetBytes > 0) free else 0} بايت" + (vm.ledgerTick.let { "" }))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !vm.txRunning, onClick = { vm.upload() }) { Text("رفع إلى الساعة") }
            OutlinedButton(enabled = vm.txRunning, onClick = { vm.cancelUpload() }) { Text("إلغاء") }
        }
        if (vm.txTotal > 0) {
            LinearProgressIndicator(progress = { vm.txDone.toFloat() / vm.txTotal }, modifier = Modifier.fillMaxWidth())
            Text("${vm.txDone}/${vm.txTotal}")
        }
        Text(vm.txMessage)
    }
}

@Composable
private fun SpaceTab(vm: AppViewModel) {
    var budget by remember { mutableStateOf((vm.ledger.budgetBytes / 1024).toString()) }
    var reserve by remember { mutableStateOf(vm.ledger.reservePercent.toString()) }
    val tick = vm.ledgerTick
    Text("لا يوجد في بروتوكول الساعة أمر لقراءة المساحة، لذلك يحسب التطبيق كل بايت يرسله ويرفض أي رفع يتجاوز السعة التي تحدّدها.", fontSize = 13.sp)
    OutlinedTextField(value = budget, onValueChange = { budget = it; it.toLongOrNull()?.let { k -> vm.ledger.budgetBytes = k * 1024; vm.ledgerTick++ } },
        label = { Text("سعة التخزين المخصصة (KB)") }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(value = reserve, onValueChange = { reserve = it; it.toIntOrNull()?.let { p -> vm.ledger.reservePercent = p; vm.ledgerTick++ } },
        label = { Text("احتياطي أمان %") }, modifier = Modifier.fillMaxWidth())
    Text("المستخدم: ${vm.ledger.usedBytes()}  |  الاحتياطي: ${vm.ledger.reserveBytes()}  |  المتاح: ${vm.ledger.freeBytes()}  (#$tick)")
    vm.ledger.entries().forEach { e ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${e.name} [${e.kind}] ${e.bytes}B")
            OutlinedButton(onClick = { vm.ledger.remove(e.id); vm.ledgerTick++ }) { Text("حذف من السجل") }
        }
    }
    Text("حذف عنصر من السجل لا يحذفه من الساعة؛ استخدم ذلك بعد حذفه من الساعة نفسها.", fontSize = 12.sp)
}

@Composable
private fun LabTab(vm: AppViewModel) {
    var cmd by remember { mutableStateOf("20") }
    var sub by remember { mutableStateOf("02") }
    var payload by remember { mutableStateOf("") }
    var raw by remember { mutableStateOf("") }
    Text("إطار مخصّص", fontSize = 16.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(cmd, { cmd = it }, label = { Text("cmd") }, modifier = Modifier.weight(1f))
        OutlinedTextField(sub, { sub = it }, label = { Text("sub") }, modifier = Modifier.weight(1f))
    }
    OutlinedTextField(payload, { payload = it }, label = { Text("payload HEX") }, modifier = Modifier.fillMaxWidth())
    Button(onClick = {
        val c = Hex.decode(cmd)?.firstOrNull()
        val s = Hex.decode(sub)?.firstOrNull()
        val p = Hex.decode(payload)
        if (c == null || s == null || p == null) vm.log("قيم غير صالحة")
        else vm.send(Frame.build(c.toInt() and 0xFF, s.toInt() and 0xFF, p))
    }) { Text("إرسال الإطار") }
    Text("HEX خام", fontSize = 16.sp)
    OutlinedTextField(raw, { raw = it }, label = { Text("CD 00 02 13 01") }, modifier = Modifier.fillMaxWidth())
    Button(onClick = { vm.sendHex(raw) }) { Text("إرسال خام") }
    Text("أوامر جاهزة", fontSize = 16.sp)
    Commands.presets().forEach { p ->
        OutlinedButton(onClick = { vm.send(p.frame) }, modifier = Modifier.fillMaxWidth()) {
            Text(p.title + (if (p.confidence == Confidence.INFERRED) "  (مستنتج)" else "") + (if (p.dangerous) "  ⚠" else ""))
        }
    }
}

@Composable
private fun LogTab(vm: AppViewModel) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { vm.copyLog() }) { Text("نسخ السجل") }
        OutlinedButton(onClick = { vm.logs.clear() }) { Text("مسح") }
    }
    vm.logs.asReversed().take(300).forEach { Text(it, fontSize = 11.sp) }
}
