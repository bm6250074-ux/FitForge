package com.fitforge.app.pkg

import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * .fpk = zip { manifest.json, payload.bin }
 * manifest: { "name", "kind": "dial|game|file", "version", "sha256", "target": "optional model", "note" }
 */
data class FpkPackage(
    val name: String,
    val kind: String,
    val version: String,
    val target: String,
    val note: String,
    val payload: ByteArray,
)

object Fpk {
    const val MAX_PAYLOAD = 8 * 1024 * 1024
    val KINDS = listOf("dial", "game", "file")

    fun sha256(b: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    fun pack(name: String, kind: String, version: String, target: String, note: String, payload: ByteArray): ByteArray {
        require(kind in KINDS) { "kind" }
        require(payload.size <= MAX_PAYLOAD) { "payload too large" }
        val man = JSONObject()
            .put("name", name).put("kind", kind).put("version", version)
            .put("target", target).put("note", note)
            .put("size", payload.size).put("sha256", sha256(payload))
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { z ->
            z.putNextEntry(ZipEntry("manifest.json"))
            z.write(man.toString(2).toByteArray(Charsets.UTF_8))
            z.closeEntry()
            z.putNextEntry(ZipEntry("payload.bin"))
            z.write(payload)
            z.closeEntry()
        }
        return bos.toByteArray()
    }

    /** Throws IllegalArgumentException with a readable reason when the package is invalid. */
    fun unpack(raw: ByteArray): FpkPackage {
        var manifest: JSONObject? = null
        var payload: ByteArray? = null
        ZipInputStream(ByteArrayInputStream(raw)).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                val out = ByteArrayOutputStream()
                val buf = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = z.read(buf)
                    if (n < 0) break
                    total += n
                    require(total <= MAX_PAYLOAD + 65536) { "الحزمة كبيرة بشكل غير طبيعي" }
                    out.write(buf, 0, n)
                }
                when (e.name) {
                    "manifest.json" -> manifest = JSONObject(String(out.toByteArray(), Charsets.UTF_8))
                    "payload.bin" -> payload = out.toByteArray()
                }
            }
        }
        val m = manifest ?: throw IllegalArgumentException("manifest.json مفقود")
        val p = payload ?: throw IllegalArgumentException("payload.bin مفقود")
        val kind = m.optString("kind")
        require(kind in KINDS) { "نوع غير معروف: $kind" }
        require(p.isNotEmpty() && p.size <= MAX_PAYLOAD) { "حجم الحمولة غير صالح" }
        val want = m.optString("sha256")
        require(want.isEmpty() || want.equals(sha256(p), ignoreCase = true)) { "البصمة SHA-256 غير مطابقة (الملف تالف)" }
        return FpkPackage(
            m.optString("name", "unnamed"), kind, m.optString("version", "1"),
            m.optString("target"), m.optString("note"), p
        )
    }
}
