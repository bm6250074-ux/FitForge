package com.fitforge.app.ui

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fitforge.app.ble.BleLink
import com.fitforge.app.ble.LinkState
import com.fitforge.app.pkg.Fpk
import com.fitforge.app.protocol.Commands
import com.fitforge.app.protocol.DialInfo
import com.fitforge.app.protocol.Frame
import com.fitforge.app.protocol.Hex
import com.fitforge.app.protocol.Proto
import com.fitforge.app.storage.Ledger
import com.fitforge.app.storage.LedgerEntry
import com.fitforge.app.transfer.Channel2
import com.fitforge.app.transfer.TransferEngine
import com.fitforge.app.transfer.TxConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val logs = mutableStateListOf<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    fun log(s: String) {
        val line = fmt.format(Date()) + "  " + s
        viewModelScope.launch(Dispatchers.Main) {
            logs.add(line)
            while (logs.size > 800) logs.removeAt(0)
        }
    }

    val link = BleLink(app) { log(it) }
    val ledger = Ledger(app)
    val engine = TransferEngine(link) { log(it) }
    val cfg = TxConfig()

    var ledgerTick by mutableIntStateOf(0)
    var dialInfo by mutableStateOf<DialInfo?>(null)

    var pickedName by mutableStateOf("")
    var pickedBytes by mutableStateOf<ByteArray?>(null)
    var pickedKind by mutableStateOf("dial")
    var pickedNote by mutableStateOf("")

    var txRunning by mutableStateOf(false)
    var txDone by mutableIntStateOf(0)
    var txTotal by mutableIntStateOf(0)
    var txMessage by mutableStateOf("")
    var dialStartHex by mutableStateOf("00 00 FF FF FF")
    private var txJob: Job? = null

    init {
        viewModelScope.launch {
            link.frames.collect { f ->
                if (f.cmd == Proto.CMD_DIAL_INFO && f.sub == 2) {
                    val d = DialInfo.parse(f.payload)
                    if (d != null) {
                        dialInfo = d
                        log("معلومات الواجهة: " + d.summary())
                    }
                }
            }
        }
    }

    fun send(f: Frame) {
        viewModelScope.launch { if (!link.send(f)) log("تعذّر الإرسال (غير متصل؟)") }
    }

    fun sendHex(text: String) {
        val b = Hex.decode(text)
        if (b == null || b.isEmpty()) { log("HEX غير صالح"); return }
        viewModelScope.launch {
            log("> RAW " + Hex.encode(b))
            if (!link.sendRaw(b)) log("تعذّر الإرسال")
        }
    }

    /** Repair: clear GATT cache, reconnect, then resync the clock once ready. */
    fun repairConnection() {
        viewModelScope.launch {
            log("إصلاح الاتصال: مسح الذاكرة المؤقتة وإعادة الاتصال")
            link.refreshCache()
            link.disconnect()
            kotlinx.coroutines.delay(1200)
            link.reconnect()
            var waited = 0
            while (link.state.value != LinkState.READY && waited < 15000) {
                kotlinx.coroutines.delay(250); waited += 250
            }
            if (link.state.value == LinkState.READY) {
                link.send(Commands.syncTime())
                link.send(Commands.readDialInfo())
                log("تم الإصلاح ومزامنة الوقت")
            } else log("لم ينجح الإصلاح — قرّب الساعة وأعد المحاولة")
        }
    }

    fun pick(uri: Uri) {
        viewModelScope.launch {
            try {
                val ctx = getApplication<Application>()
                val (name, bytes) = withContext(Dispatchers.IO) {
                    var n = "file.bin"
                    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (i >= 0 && c.moveToFirst()) n = c.getString(i)
                    }
                    val b = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
                    n to b
                }
                if (bytes.size > Fpk.MAX_PAYLOAD + 65536) { log("الملف أكبر من 8MB"); return@launch }
                if (name.endsWith(".fpk", true)) {
                    val p = Fpk.unpack(bytes)
                    pickedName = p.name; pickedBytes = p.payload; pickedKind = p.kind; pickedNote = p.note
                    log("حزمة fpk سليمة: ${p.name} (${p.kind}) ${p.payload.size} بايت")
                } else {
                    pickedName = name; pickedBytes = bytes; pickedNote = ""
                    log("ملف: $name ${bytes.size} بايت")
                }
            } catch (e: Exception) {
                log("ملف مرفوض: ${e.message}")
            }
        }
    }

    fun upload() {
        val data = pickedBytes ?: return
        if (txRunning) return
        if (link.state.value != LinkState.READY) { txMessage = "غير متصل بالساعة"; return }
        val refusal = ledger.check(data.size.toLong(), idFor(pickedName))
        if (refusal != null) { txMessage = refusal; log(refusal); return }
        val ch = if (pickedKind == "dial") Channel2.DIAL else Channel2.FILE
        val startPayload = Hex.decode(dialStartHex) ?: ByteArray(0)
        txRunning = true; txDone = 0; txTotal = 0; txMessage = "جارٍ الإرسال ..."
        val name = pickedName; val kind = pickedKind
        txJob = viewModelScope.launch {
            val r = try {
                engine.push(ch, data, startPayload, cfg) { d, t -> txDone = d; txTotal = t }
            } catch (e: kotlinx.coroutines.CancellationException) {
                com.fitforge.app.transfer.TxResult(false, false, "أُلغي")
            } catch (e: Exception) {
                com.fitforge.app.transfer.TxResult(false, false, "خطأ: ${e.message}")
            }
            txMessage = r.message
            log("النتيجة: ${r.message}")
            if (r.ok && r.confirmed) {
                ledger.add(LedgerEntry(idFor(name), name, kind, data.size.toLong(), System.currentTimeMillis()))
                ledgerTick++
            }
            txRunning = false
        }
    }

    fun cancelUpload() { txJob?.cancel(); log("طُلب إلغاء الرفع") }

    private fun idFor(name: String) = name.lowercase(Locale.ROOT)

    fun buildFpk(name: String, kind: String, note: String): ByteArray? {
        val d = pickedBytes ?: return null
        return try { Fpk.pack(name, kind, "1", dialInfo?.mainModel ?: "", note, d) } catch (e: Exception) { log("فشل التعبئة: ${e.message}"); null }
    }

    fun copyLog() {
        val cm = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("log", logs.joinToString("\n")))
        log("نُسخ السجل")
    }

    override fun onCleared() { link.disconnect() }
}
