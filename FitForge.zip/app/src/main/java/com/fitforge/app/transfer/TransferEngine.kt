package com.fitforge.app.transfer

import com.fitforge.app.ble.BleLink
import com.fitforge.app.protocol.Commands
import com.fitforge.app.protocol.Frame
import com.fitforge.app.protocol.Hex
import com.fitforge.app.protocol.Proto
import com.fitforge.app.protocol.Sum
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.coroutineContext

enum class Channel2(val cmd: Int, val label: String) {
    DIAL(Proto.CMD_DIAL_PUSH, "واجهة"),
    FILE(Proto.CMD_FILE_PUSH, "ملف/لعبة"),
}

class TxConfig(
    var chunk: Int = 120,
    var ackTimeoutMs: Long = 500,
    var maxResends: Int = 3,
    var paceMs: Long = 12,
    var startAckTimeoutMs: Long = 5000,
    var finishAckTimeoutMs: Long = 10000,
)

data class TxPlan(val packets: Int, val sum: Long, val estSeconds: Int)

data class TxResult(val ok: Boolean, val confirmed: Boolean, val message: String)

/**
 * Packet format (recovered from WatchThemeTools / BleFileSendTools):
 *   start : sub 2, payload = BE32(length) ++ BE32(sum of bytes)      (dial: custom start payload)
 *   data  : sub 1, payload = BE16(seq, from 1) ++ data[<=chunk] ++ sum16(seq ++ data)
 *   finish: sub 3, payload = BE32(length) ++ BE32(sum)  (dial)  /  none (file)
 */
class TransferEngine(private val link: BleLink, private val log: (String) -> Unit) {

    fun plan(data: ByteArray, cfg: TxConfig): TxPlan {
        val packets = (data.size + cfg.chunk - 1) / cfg.chunk
        val ms = packets.toLong() * (cfg.paceMs + 40)
        return TxPlan(packets, Sum.sum(data), (ms / 1000).toInt() + 1)
    }

    fun lenAndSum(data: ByteArray): ByteArray = Sum.be32(data.size.toLong()) + Sum.be32(Sum.sum(data))

    fun dataPayload(seq: Int, part: ByteArray): ByteArray {
        val body = Sum.be16(seq) + part
        return body + Sum.sum16(body)
    }

    suspend fun push(
        ch: Channel2,
        data: ByteArray,
        dialStartPayload: ByteArray,
        cfg: TxConfig,
        onProgress: (done: Int, total: Int) -> Unit,
    ): TxResult {
        val scope = CoroutineScope(Dispatchers.Default)
        val inbox = Channel<Frame>(Channel.UNLIMITED)
        val job = scope.launch {
            link.frames.collect { f -> if (f.cmd == ch.cmd) inbox.trySend(f) }
        }
        try {
            if (data.isEmpty()) return TxResult(false, false, "الملف فارغ")
            if (cfg.chunk < 16 || cfg.chunk > 240) return TxResult(false, false, "حجم الحزمة خارج النطاق 16..240")
            val total = (data.size + cfg.chunk - 1) / cfg.chunk

            // 1) start — nothing is streamed unless the watch answers this
            val startPayload = if (ch == Channel2.DIAL) dialStartPayload else lenAndSum(data)
            if (!link.send(Frame.build(ch.cmd, Proto.SUB_START, startPayload)))
                return TxResult(false, false, "فشل إرسال أمر البدء")
            val startAck = withTimeoutOrNull(cfg.startAckTimeoutMs) { inbox.receive() }
            if (startAck == null) return TxResult(false, false, "الساعة لم تردّ على أمر البدء — أُلغي الإرسال دون إرسال بيانات")
            log("ردّ البدء: $startAck")

            // 2) data
            var perPacketAck = true
            var seq = 1
            var pos = 0
            while (pos < data.size) {
                coroutineContext.ensureActive()
                val end = minOf(data.size, pos + cfg.chunk)
                val frame = Frame.build(ch.cmd, Proto.SUB_DATA, dataPayload(seq, data.copyOfRange(pos, end)))
                var tries = 0
                var acked = false
                while (true) {
                    while (inbox.tryReceive().isSuccess) { /* drop stale acks */ }
                    if (!link.sendRaw(frame.toBytes(), cfg.paceMs)) {
                        return TxResult(false, false, "انقطع الإرسال عند الحزمة $seq/$total")
                    }
                    if (!perPacketAck) break
                    val a = withTimeoutOrNull(cfg.ackTimeoutMs) { inbox.receive() }
                    if (a != null) { acked = true; break }
                    tries++
                    if (tries > cfg.maxResends) break
                    log("لا ردّ على الحزمة $seq — إعادة ($tries)")
                }
                if (perPacketAck && !acked) {
                    if (seq == 1) {
                        perPacketAck = false
                        log("الساعة لا ترسل ردّاً لكل حزمة — التحوّل لوضع الإيقاع الثابت")
                    } else {
                        return TxResult(false, false, "توقفت الساعة عن الرد عند الحزمة $seq/$total")
                    }
                }
                seq++
                pos = end
                onProgress(seq - 1, total)
            }

            // 3) finish
            val finish = if (ch == Channel2.DIAL) Frame.build(ch.cmd, Proto.SUB_FINISH, lenAndSum(data))
            else Frame.build(ch.cmd, Proto.SUB_FINISH)
            while (inbox.tryReceive().isSuccess) { }
            if (!link.send(finish)) return TxResult(false, false, "فشل إرسال أمر الإنهاء")
            val fin = withTimeoutOrNull(cfg.finishAckTimeoutMs) { inbox.receive() }
            delay(300)
            link.send(if (ch == Channel2.DIAL) Commands.readDialStatus() else Commands.readFileStatus())
            return if (fin != null) {
                log("ردّ الإنهاء: $fin")
                TxResult(true, true, "اكتمل الإرسال وردّت الساعة: ${Hex.encode(fin.payload, 16)}")
            } else {
                TxResult(true, false, "أُرسلت كل الحزم لكن الساعة لم تؤكد الإنهاء — راجع السجل وحالة الساعة")
            }
        } finally {
            job.cancel()
            inbox.close()
        }
    }
}
