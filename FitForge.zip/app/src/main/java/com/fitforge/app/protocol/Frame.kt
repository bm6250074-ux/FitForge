package com.fitforge.app.protocol

/**
 * Wire format recovered from FitPro 2.11.1 (SendData.getProtocol / getNoValueProtocol):
 *
 *   long frame : HEAD | LEN(2,BE) | CMD | 0x01 | SUB | PLEN(2,BE) | PAYLOAD
 *   short frame: HEAD | LEN(2,BE) | CMD | 0x01                       (LEN == 2)
 *
 * LEN = total frame size - 3.  App -> watch HEAD is 0xCD, watch -> app HEAD is 0xDC.
 */
object Proto {
    const val TX_HEAD = 0xCD
    const val RX_HEAD = 0xDC

    const val CMD_TIME = 0x1C          // timestamp sync (sub 0x10)
    const val CMD_DIAL_PUSH = 0x1F     // dial transfer
    const val CMD_DIAL_INFO = 0x20     // dial info / status
    const val CMD_FILE_PUSH = 0x22     // generic file transfer
    const val CMD_FILE_STATUS = 0x23

    const val SUB_DATA = 1
    const val SUB_START = 2
    const val SUB_FINISH = 3

    const val MAX_FRAME = 4096
}

class Frame(
    val head: Int,
    val cmd: Int,
    val flag: Int,
    val sub: Int,
    val payload: ByteArray,
    val isShort: Boolean,
) {
    fun toBytes(): ByteArray {
        if (isShort) {
            return byteArrayOf(
                head.toByte(), 0, 2, cmd.toByte(), flag.toByte()
            )
        }
        val total = 8 + payload.size
        val len = total - 3
        val out = ByteArray(total)
        out[0] = head.toByte()
        out[1] = (len shr 8).toByte()
        out[2] = len.toByte()
        out[3] = cmd.toByte()
        out[4] = flag.toByte()
        out[5] = sub.toByte()
        out[6] = (payload.size shr 8).toByte()
        out[7] = payload.size.toByte()
        payload.copyInto(out, 8)
        return out
    }

    override fun toString(): String =
        "%s cmd=0x%02X sub=%s len=%d [%s]".format(
            if (head == Proto.RX_HEAD) "RX" else "TX",
            cmd,
            if (isShort) "-" else "0x%02X".format(sub),
            payload.size,
            Hex.encode(payload, 48)
        )

    companion object {
        fun build(cmd: Int, sub: Int, payload: ByteArray = ByteArray(0)): Frame =
            Frame(Proto.TX_HEAD, cmd, 1, sub, payload, false)

        fun short(cmd: Int): Frame = Frame(Proto.TX_HEAD, cmd, 1, 0, ByteArray(0), true)

        /** Parses one complete frame (exactly LEN+3 bytes). Returns null if malformed. */
        fun parse(b: ByteArray): Frame? {
            if (b.size < 5) return null
            val head = b[0].toInt() and 0xFF
            if (head != Proto.RX_HEAD && head != Proto.TX_HEAD) return null
            val len = ((b[1].toInt() and 0xFF) shl 8) or (b[2].toInt() and 0xFF)
            if (len + 3 != b.size) return null
            val cmd = b[3].toInt() and 0xFF
            val flag = b[4].toInt() and 0xFF
            if (b.size == 5) return Frame(head, cmd, flag, 0, ByteArray(0), true)
            if (b.size < 8) return null
            val sub = b[5].toInt() and 0xFF
            val plen = ((b[6].toInt() and 0xFF) shl 8) or (b[7].toInt() and 0xFF)
            val avail = b.size - 8
            val n = if (plen <= avail) plen else avail
            return Frame(head, cmd, flag, sub, b.copyOfRange(8, 8 + n), false)
        }
    }
}

/** Re-assembles frames that arrive split over several BLE notifications. */
class FrameAssembler {
    private var buf = ByteArray(0)

    @Synchronized
    fun feed(chunk: ByteArray): List<Frame> {
        buf += chunk
        val out = ArrayList<Frame>()
        while (true) {
            var start = 0
            while (start < buf.size) {
                val h = buf[start].toInt() and 0xFF
                if (h == Proto.RX_HEAD || h == Proto.TX_HEAD) break
                start++
            }
            if (start > 0) buf = buf.copyOfRange(start, buf.size)
            if (buf.size < 3) break
            val len = ((buf[1].toInt() and 0xFF) shl 8) or (buf[2].toInt() and 0xFF)
            val total = len + 3
            if (total < 5 || total > Proto.MAX_FRAME) {
                buf = buf.copyOfRange(1, buf.size)
                continue
            }
            if (buf.size < total) break
            val f = Frame.parse(buf.copyOfRange(0, total))
            if (f != null) out.add(f)
            buf = buf.copyOfRange(total, buf.size)
        }
        return out
    }

    @Synchronized
    fun reset() {
        buf = ByteArray(0)
    }
}

object Hex {
    fun encode(b: ByteArray, max: Int = Int.MAX_VALUE): String {
        val n = if (b.size < max) b.size else max
        val sb = StringBuilder()
        for (i in 0 until n) {
            sb.append("%02X".format(b[i].toInt() and 0xFF))
            if (i != n - 1) sb.append(' ')
        }
        if (b.size > n) sb.append(" …(+").append(b.size - n).append(")")
        return sb.toString()
    }

    /** Accepts "CD 00 02", "cd0002", "0xCD,0x00" ... Returns null when invalid. */
    fun decode(text: String): ByteArray? {
        val clean = text.replace("0x", "", ignoreCase = true)
            .filter { it.isLetterOrDigit() }
        if (clean.isEmpty()) return ByteArray(0)
        if (clean.length % 2 != 0) return null
        val out = ByteArray(clean.length / 2)
        for (i in out.indices) {
            val hi = Character.digit(clean[i * 2], 16)
            val lo = Character.digit(clean[i * 2 + 1], 16)
            if (hi < 0 || lo < 0) return null
            out[i] = ((hi shl 4) or lo).toByte()
        }
        return out
    }
}

object Sum {
    /** Sum of unsigned bytes. */
    fun sum(b: ByteArray): Long {
        var s = 0L
        for (x in b) s += (x.toInt() and 0xFF)
        return s
    }

    fun sum16(b: ByteArray): ByteArray {
        val s = (sum(b) and 0xFFFF).toInt()
        return byteArrayOf((s shr 8).toByte(), s.toByte())
    }

    fun be32(v: Long): ByteArray = byteArrayOf(
        (v shr 24).toByte(), (v shr 16).toByte(), (v shr 8).toByte(), v.toByte()
    )

    fun be16(v: Int): ByteArray = byteArrayOf((v shr 8).toByte(), v.toByte())
}
