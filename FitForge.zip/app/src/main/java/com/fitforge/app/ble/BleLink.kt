package com.fitforge.app.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Handler
import android.os.Looper
import com.fitforge.app.protocol.Frame
import com.fitforge.app.protocol.FrameAssembler
import com.fitforge.app.protocol.Hex
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID

data class ScanItem(val name: String, val address: String, val rssi: Int)

enum class LinkState { IDLE, SCANNING, CONNECTING, READY, ERROR }

/**
 * Nordic-UART style link used by FitPro watches:
 *   write  characteristic 6e400002-b5a3-f393-e0a9-e50e24dcca9d
 *   notify characteristic 6e400003-b5a3-f393-e0a9-e50e24dcca9d
 */
@SuppressLint("MissingPermission")
class BleLink(private val ctx: Context, private val log: (String) -> Unit) {

    companion object {
        val WRITE_UUID: UUID = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9d")
        val NOTIFY_UUID: UUID = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9d")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }

    val state = MutableStateFlow(LinkState.IDLE)
    val devices = MutableStateFlow<List<ScanItem>>(emptyList())
    val frames = MutableSharedFlow<Frame>(extraBufferCapacity = 256)
    val mtu = MutableStateFlow(23)
    val deviceName = MutableStateFlow("")

    private val main = Handler(Looper.getMainLooper())
    private val adapter: BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var notifyChar: BluetoothGattCharacteristic? = null
    private var writeDone: CompletableDeferred<Boolean>? = null
    private val writeMutex = Mutex()
    private val assembler = FrameAssembler()
    private val found = LinkedHashMap<String, ScanItem>()
    private var lastAddress: String? = null

    // ---------------------------------------------------------------- scanning
    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val dev = result.device ?: return
            val name = try { dev.name } catch (e: SecurityException) { null } ?: result.scanRecord?.deviceName ?: ""
            found[dev.address] = ScanItem(name, dev.address, result.rssi)
            devices.value = found.values.sortedByDescending { it.rssi }
        }

        override fun onScanFailed(errorCode: Int) {
            log("فشل المسح: $errorCode")
            state.value = LinkState.ERROR
        }
    }

    fun startScan() {
        val a = adapter
        if (a == null || !a.isEnabled) {
            log("البلوتوث مغلق أو غير مدعوم")
            state.value = LinkState.ERROR
            return
        }
        found.clear()
        devices.value = emptyList()
        try {
            a.bluetoothLeScanner?.startScan(scanCb)
            state.value = LinkState.SCANNING
            main.postDelayed({ stopScan() }, 15000)
        } catch (e: Exception) {
            log("تعذّر بدء المسح: ${e.message}")
            state.value = LinkState.ERROR
        }
    }

    fun stopScan() {
        try { adapter?.bluetoothLeScanner?.stopScan(scanCb) } catch (_: Exception) {}
        if (state.value == LinkState.SCANNING) state.value = LinkState.IDLE
    }

    // -------------------------------------------------------------- connecting
    fun connect(address: String) {
        stopScan()
        val a = adapter ?: return
        closeGatt()
        lastAddress = address
        state.value = LinkState.CONNECTING
        try {
            val dev = a.getRemoteDevice(address)
            deviceName.value = try { dev.name ?: address } catch (e: SecurityException) { address }
            gatt = dev.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
            log("اتصال بـ $address ...")
        } catch (e: Exception) {
            log("فشل الاتصال: ${e.message}")
            state.value = LinkState.ERROR
        }
    }

    fun reconnect() {
        val addr = lastAddress ?: return
        connect(addr)
    }

    fun disconnect() {
        try { gatt?.disconnect() } catch (_: Exception) {}
        main.postDelayed({ closeGatt(); state.value = LinkState.IDLE }, 400)
    }

    /** Clears Android's cached service table (fixes "services not found"/stale-GATT problems). */
    fun refreshCache(): Boolean {
        val g = gatt ?: return false
        return try {
            val m = g.javaClass.getMethod("refresh")
            (m.invoke(g) as? Boolean) ?: false
        } catch (e: Exception) {
            log("refresh غير متاح: ${e.message}")
            false
        }
    }

    private fun closeGatt() {
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
        writeChar = null
        notifyChar = null
        assembler.reset()
        writeDone?.complete(false)
    }

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == android.bluetooth.BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                log("متصل. طلب MTU ...")
                if (!g.requestMtu(247)) g.discoverServices()
            } else {
                log("انقطع الاتصال (status=$status)")
                main.post {
                    closeGatt()
                    state.value = if (status == BluetoothGatt.GATT_SUCCESS) LinkState.IDLE else LinkState.ERROR
                }
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, m: Int, status: Int) {
            mtu.value = m
            log("MTU=$m")
            g.discoverServices()
        }

        @Suppress("DEPRECATION")
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            var w: BluetoothGattCharacteristic? = null
            var n: BluetoothGattCharacteristic? = null
            for (s in g.services) {
                val sb = StringBuilder("خدمة ${s.uuid}: ")
                for (c in s.characteristics) {
                    sb.append(c.uuid.toString().substring(0, 8)).append(' ')
                    if (c.uuid == WRITE_UUID) w = c
                    if (c.uuid == NOTIFY_UUID) n = c
                }
                log(sb.toString())
            }
            if (w == null || n == null) {
                log("لم أجد قناتي 6e400002/6e400003 — جرّب «إصلاح الاتصال» ثم أعد الاتصال")
                state.value = LinkState.ERROR
                return
            }
            writeChar = w
            notifyChar = n
            g.setCharacteristicNotification(n, true)
            val d = n.getDescriptor(CCCD)
            if (d == null) {
                state.value = LinkState.READY
                return
            }
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            g.writeDescriptor(d)
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            log("الإشعارات مفعّلة (status=$status) — جاهز")
            state.value = LinkState.READY
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            writeDone?.complete(status == BluetoothGatt.GATT_SUCCESS)
        }

        @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val v = c.value ?: return
            log("RAW< " + Hex.encode(v, 40))
            for (f in assembler.feed(v)) {
                frames.tryEmit(f)
                log("< $f")
            }
        }
    }

    // ----------------------------------------------------------------- writing
    suspend fun send(frame: Frame): Boolean {
        log("> $frame")
        return sendRaw(frame.toBytes())
    }

    @Suppress("DEPRECATION")
    suspend fun sendRaw(data: ByteArray, paceMs: Long = 6): Boolean = writeMutex.withLock {
        val g = gatt
        val c = writeChar
        if (g == null || c == null || state.value != LinkState.READY) return@withLock false
        val chunk = maxOf(20, mtu.value - 3)
        var off = 0
        while (off < data.size) {
            val end = minOf(data.size, off + chunk)
            val part = data.copyOfRange(off, end)
            val withResp = (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0
            c.writeType = if (withResp) BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            c.value = part
            val done = CompletableDeferred<Boolean>()
            writeDone = done
            var queued = false
            var tries = 0
            while (!queued && tries < 20) {
                queued = g.writeCharacteristic(c)
                if (!queued) { tries++; delay(15) }
            }
            if (!queued) { log("فشل إدراج الكتابة"); return@withLock false }
            val ok = withTimeoutOrNull(3000) { done.await() }
            if (ok == null) {
                if (withResp) { log("انتهت مهلة الكتابة"); return@withLock false }
            } else if (!ok) {
                log("الكتابة رُفضت"); return@withLock false
            }
            off = end
            if (paceMs > 0) delay(paceMs)
        }
        true
    }
}
