package com.fitforge.app.protocol

import java.util.TimeZone

enum class Confidence { VERIFIED, INFERRED }

class Preset(
    val title: String,
    val description: String,
    val frame: Frame,
    val confidence: Confidence,
    val dangerous: Boolean = false,
)

object Commands {
    /** Constant frames copied byte-for-byte from SendData (getIsBingding / getResetDevice). */
    val bindCheckA = Frame.short(0x13)
    val bindCheckB = Frame.short(0x14)
    val resetWatch = Frame.short(0x1D)

    fun readDialInfo(): Frame = Frame.build(Proto.CMD_DIAL_INFO, 2)
    fun readDialStatus(): Frame = Frame.build(Proto.CMD_DIAL_INFO, 1)
    fun readFileStatus(): Frame = Frame.build(Proto.CMD_FILE_STATUS, 0)

    /** FitPro: payload = BE32(epochSeconds + rawTimezoneOffsetSeconds). */
    fun syncTime(nowMs: Long = System.currentTimeMillis()): Frame {
        val off = TimeZone.getDefault().getOffset(nowMs) / 1000
        val v = nowMs / 1000 + off
        return Frame.build(Proto.CMD_TIME, 0x10, Sum.be32(v))
    }

    fun presets(): List<Preset> = listOf(
        Preset("قراءة معلومات الواجهة", "cmd 0x20 / sub 2", readDialInfo(), Confidence.VERIFIED),
        Preset("قراءة حالة رفع الواجهة", "cmd 0x20 / sub 1", readDialStatus(), Confidence.VERIFIED),
        Preset("فحص الربط A", "CD 00 02 13 01", bindCheckA, Confidence.VERIFIED),
        Preset("فحص الربط B", "CD 00 02 14 01", bindCheckB, Confidence.VERIFIED),
        Preset("مزامنة الوقت", "cmd 0x1C / sub 0x10", syncTime(), Confidence.INFERRED),
        Preset("حالة نقل الملفات", "cmd 0x23", readFileStatus(), Confidence.INFERRED),
        Preset("إعادة ضبط الساعة", "CD 00 02 1D 01 (يمسح بيانات الساعة)", resetWatch, Confidence.VERIFIED, true),
    )
}
