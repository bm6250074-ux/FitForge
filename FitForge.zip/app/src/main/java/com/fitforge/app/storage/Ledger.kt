package com.fitforge.app.storage

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class LedgerEntry(
    val id: String,
    val name: String,
    val kind: String,
    val bytes: Long,
    val time: Long,
)

/**
 * The watch protocol recovered from FitPro has no "free space" query, so the app keeps its own
 * exact accounting: a user-set storage budget, a safety reserve, and every byte this app has
 * sent. Uploads that would not fit inside (budget - reserve - used) are refused.
 */
class Ledger(ctx: Context) {
    private val sp = ctx.getSharedPreferences("ledger", Context.MODE_PRIVATE)

    var budgetBytes: Long
        get() = sp.getLong("budget", 0L)
        set(v) { sp.edit().putLong("budget", if (v < 0) 0 else v).apply() }

    var reservePercent: Int
        get() = sp.getInt("reserve", 15)
        set(v) { sp.edit().putInt("reserve", v.coerceIn(0, 90)).apply() }

    fun entries(): List<LedgerEntry> {
        val raw = sp.getString("entries", "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (e: Exception) { JSONArray() }
        val out = ArrayList<LedgerEntry>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(
                LedgerEntry(
                    o.optString("id"), o.optString("name"), o.optString("kind"),
                    o.optLong("bytes"), o.optLong("time")
                )
            )
        }
        return out
    }

    private fun save(list: List<LedgerEntry>) {
        val arr = JSONArray()
        for (e in list) {
            arr.put(
                JSONObject().put("id", e.id).put("name", e.name).put("kind", e.kind)
                    .put("bytes", e.bytes).put("time", e.time)
            )
        }
        sp.edit().putString("entries", arr.toString()).apply()
    }

    fun usedBytes(): Long = entries().sumOf { it.bytes }

    fun reserveBytes(): Long = budgetBytes * reservePercent / 100

    /** Bytes still safely usable. Negative means over budget. */
    fun freeBytes(): Long = budgetBytes - reserveBytes() - usedBytes()

    /** Returns null if the upload fits, otherwise a human-readable refusal. */
    fun check(size: Long, replacingId: String? = null): String? {
        if (budgetBytes <= 0) return "حدّد سعة الساعة أولاً في تبويب المساحة (الساعة لا تُخبر التطبيق بسعتها)."
        val reuse = if (replacingId == null) 0L else entries().filter { it.id == replacingId }.sumOf { it.bytes }
        val free = freeBytes() + reuse
        if (size > free) return "الحجم ${size} بايت أكبر من المتاح الآمن ${if (free < 0) 0 else free} بايت."
        return null
    }

    fun add(e: LedgerEntry) {
        val list = entries().filter { it.id != e.id }.toMutableList()
        list.add(e)
        save(list)
    }

    fun remove(id: String) = save(entries().filter { it.id != id })

    fun clear() = save(emptyList())
}
