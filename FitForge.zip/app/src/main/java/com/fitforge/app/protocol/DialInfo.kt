package com.fitforge.app.protocol

/**
 * Response to CMD 0x20 / SUB 0x02 (BaseReceiveData.parseDialInfo in FitPro).
 * Payload layout:
 *  [0] screenType  [1] grade  [2..3] width  [4..5] height
 *  [6] len, then mchModel string
 *  [..] len, then mainModel string
 *  [..] config  [..] algorithm  [..] remaining bytes (version / customer / picture info)
 */
data class DialInfo(
    val screenType: Int,
    val grade: Int,
    val width: Int,
    val height: Int,
    val mchModel: String,
    val mainModel: String,
    val config: Int,
    val algorithm: Int,
    val rest: ByteArray,
) {
    fun summary(): String =
        "الشاشة ${width}x$height | الطراز $mainModel / $mchModel | config=$config algo=$algorithm | " +
            "بقية=${Hex.encode(rest, 24)}"

    companion object {
        fun parse(p: ByteArray): DialInfo? {
            if (p.size < 8) return null
            fun u8(i: Int) = p[i].toInt() and 0xFF
            fun u16(i: Int) = (u8(i) shl 8) or u8(i + 1)
            val screenType = u8(0)
            val grade = u8(1)
            val width = u16(2)
            val height = u16(4)
            val mchLen = u8(6)
            if (7 + mchLen >= p.size) return null
            val mch = String(p, 7, mchLen, Charsets.UTF_8)
            var idx = 7 + mchLen
            val mainLen = u8(idx)
            if (idx + 1 + mainLen > p.size) return null
            val main = String(p, idx + 1, mainLen, Charsets.UTF_8)
            idx += 1 + mainLen
            val config = if (idx < p.size) u8(idx) else 0
            val algo = if (idx + 1 < p.size) u8(idx + 1) else 0
            val rest = if (idx + 2 <= p.size) p.copyOfRange(idx + 2, p.size) else ByteArray(0)
            return DialInfo(screenType, grade, width, height, mch, main, config, algo, rest)
        }
    }
}
