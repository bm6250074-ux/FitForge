package com.fitforge.app

import com.fitforge.app.pkg.Fpk
import com.fitforge.app.protocol.DialInfo
import com.fitforge.app.protocol.Frame
import com.fitforge.app.protocol.FrameAssembler
import com.fitforge.app.protocol.Hex
import com.fitforge.app.protocol.Sum
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProtocolTest {
    @Test fun noValueFrameMatchesFitPro() {
        // getNoValueProtocol(cmd=0x20, sub=2): CD 00 05 20 01 02 00 00
        assertEquals("CD 00 05 20 01 02 00 00", Hex.encode(Frame.build(0x20, 2).toBytes()))
    }

    @Test fun constantFramesMatchFitPro() {
        assertEquals("CD 00 02 13 01", Hex.encode(Frame.short(0x13).toBytes()))
        assertEquals("CD 00 02 14 01", Hex.encode(Frame.short(0x14).toBytes()))
        assertEquals("CD 00 02 1D 01", Hex.encode(Frame.short(0x1D).toBytes()))
    }

    @Test fun payloadFrameLengths() {
        val b = Frame.build(0x1F, 1, ByteArray(10)).toBytes()
        assertEquals(18, b.size)
        assertEquals(15, b[2].toInt())      // total-3
        assertEquals(10, b[7].toInt())      // payload len
    }

    @Test fun assemblerHandlesFragmentsAndGarbage() {
        val full = Frame.build(0x20, 2, byteArrayOf(1, 2, 3)).toBytes()
        full[0] = 0xDC.toByte()
        val a = FrameAssembler()
        assertTrue(a.feed(byteArrayOf(0x00, 0x11) + full.copyOfRange(0, 4)).isEmpty())
        val out = a.feed(full.copyOfRange(4, full.size))
        assertEquals(1, out.size)
        assertEquals(0x20, out[0].cmd)
        assertArrayEquals(byteArrayOf(1, 2, 3), out[0].payload)
    }

    @Test fun checksums() {
        val d = byteArrayOf(0xFF.toByte(), 0x01, 0x02)
        assertEquals(0x102L, Sum.sum(d))
        assertEquals("01 02", Hex.encode(Sum.sum16(d)))
        assertEquals("00 00 01 02", Hex.encode(Sum.be32(0x102)))
    }

    @Test fun hexRoundTrip() {
        assertEquals("CD 00 02", Hex.encode(Hex.decode("0xcd,0x00 02")!!))
        assertEquals(null, Hex.decode("ABC"))
    }

    @Test fun dialInfoParses() {
        val mch = "M1".toByteArray(); val main = "W2".toByteArray()
        val p = byteArrayOf(1, 2, 0x01, 0x68, 0x01, 0x68, mch.size.toByte()) + mch +
            byteArrayOf(main.size.toByte()) + main + byteArrayOf(5, 7, 9, 9)
        val d = DialInfo.parse(p)
        assertNotNull(d)
        assertEquals(360, d!!.width); assertEquals(360, d.height)
        assertEquals("M1", d.mchModel); assertEquals("W2", d.mainModel)
        assertEquals(5, d.config); assertEquals(7, d.algorithm)
    }

    @Test fun fpkRoundTripAndHash() {
        val payload = ByteArray(1000) { it.toByte() }
        val raw = Fpk.pack("g", "game", "1", "", "n", payload)
        assertArrayEquals(payload, Fpk.unpack(raw).payload)
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", Fpk.sha256("abc".toByteArray()))
    }
}
