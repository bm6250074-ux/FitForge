# FitForge
Companion app for FitPro-protocol watches (reverse-engineered from FitPro 2.11.1).
Push the repo to GitHub, open Actions → "Build FitForge APK" → download artifact `FitForge-apk`.
